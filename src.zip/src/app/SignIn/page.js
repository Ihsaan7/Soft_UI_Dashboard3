'use client'


export default function SignIn() {
  return (
    <div>
      <h1>Sign In</h1>
    </div>
  );
}
