'use client'
import { useContext, useState } from 'react';
import { NavbarContext } from '../ClientLayout';

export default function VirtualReality() {
  const { setIsNavOpen } = useContext(NavbarContext);
  const [activeTab, setActiveTab] = useState('overview');

  // Mock data for VR projects
  const vrProjects = [
    {
      id: 1,
      title: 'Data Visualization VR',
      status: 'Active',
      lastAccessed: '2 hours ago',
      progress: 75,
    },
    {
      id: 2,
      title: '3D Analytics Dashboard',
      status: 'In Development',
      lastAccessed: '1 day ago',
      progress: 45,
    },
    {
      id: 3,
      title: 'Immersive Reports',
      status: 'Completed',
      lastAccessed: '3 days ago',
      progress: 100,
    },
  ];

  // Mock data for VR devices
  const vrDevices = [
    { id: 1, name: 'Oculus Quest 2', status: 'Connected', battery: 85 },
    { id: 2, name: 'HTC Vive Pro', status: 'Standby', battery: 60 },
  ];

  return (
    <div className="w-full py-3 flex flex-col gap-6">
      {/* Header Section */}
      <nav className="px-8 sticky top-0 z-10 bg-gray-100">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h4 className="text-gray-500">
              Pages <span className="text-black"> / VirtualReality</span>
            </h4>
            <h3 className="font-bold text-black">VirtualReality</h3>
          </div>

          <div className="flex items-center gap-4">
            <form className="flex items-center gap-4 w-full lg:w-auto text-gray-500">
              <input
                type="text"
                placeholder="Search VR projects..."
                className="border border-gray-400 rounded-lg px-4 py-2 w-full lg:w-64 focus:outline-none focus:ring-2 focus:ring-gray-300 transition-all"
              />
              <button className="border-2 border-orange-500 text-orange-500 font-bold rounded-lg px-4 py-2 hover:bg-orange-50 transition-all duration-300 whitespace-nowrap">
                Launch VR Mode
              </button>
            </form>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setIsNavOpen(true)}
              className="lg:hidden p-2 hover:bg-gray-200 rounded-xl transition-colors"
            >
              <svg className="w-6 h-6" fill="none" stroke="black" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="px-8 space-y-6">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-8 text-white">
          <h1 className="text-3xl font-bold mb-4">Welcome to Virtual Reality Dashboard</h1>
          <p className="text-lg mb-6">Experience your data in immersive 3D environments and interactive visualizations.</p>
          <div className="flex gap-4">
            <button className="bg-white text-blue-600 px-6 py-2 rounded-lg font-semibold hover:bg-blue-50 transition-all">
              Start VR Session
            </button>
            <button className="border-2 border-white px-6 py-2 rounded-lg font-semibold hover:bg-white/10 transition-all">
              Learn More
            </button>
          </div>
        </div>

        {/* Tabs Navigation */}
        <div className="flex gap-4 border-b border-gray-200">
          {['overview', 'projects', 'devices', 'analytics'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 font-medium capitalize ${
                activeTab === tab
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Content Sections */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* VR Projects Section */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-xl p-6 shadow-md">
              <h2 className="text-xl font-bold text-gray-800 mb-4">VR Projects</h2>
              <div className="space-y-4">
                {vrProjects.map((project) => (
                  <div key={project.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-all">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold text-gray-800">{project.title}</h3>
                        <p className="text-sm text-gray-500">Last accessed: {project.lastAccessed}</p>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-sm ${
                        project.status === 'Active' ? 'bg-green-100 text-green-800' :
                        project.status === 'In Development' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {project.status}
                      </span>
                    </div>
                    <div className="mt-4">
                      <div className="flex justify-between text-sm text-gray-600 mb-1">
                        <span>Progress</span>
                        <span>{project.progress}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full"
                          style={{ width: `${project.progress}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* VR Devices Section */}
          <div className="space-y-6">
            <div className="bg-white rounded-xl p-6 shadow-md">
              <h2 className="text-xl font-bold text-gray-800 mb-4">Connected Devices</h2>
              <div className="space-y-4">
                {vrDevices.map((device) => (
                  <div key={device.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="font-semibold text-gray-800">{device.name}</h3>
                        <p className="text-sm text-gray-500">Battery: {device.battery}%</p>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-sm ${
                        device.status === 'Connected' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {device.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-xl p-6 shadow-md">
              <h2 className="text-xl font-bold text-gray-800 mb-4">Quick Actions</h2>
              <div className="grid grid-cols-2 gap-4">
                <button className="bg-blue-50 text-blue-600 p-4 rounded-lg hover:bg-blue-100 transition-all">
                  <svg className="w-6 h-6 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                  <span className="text-sm font-medium">Start VR Session</span>
                </button>
                <button className="bg-purple-50 text-purple-600 p-4 rounded-lg hover:bg-purple-100 transition-all">
                  <svg className="w-6 h-6 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                  <span className="text-sm font-medium">View Analytics</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
